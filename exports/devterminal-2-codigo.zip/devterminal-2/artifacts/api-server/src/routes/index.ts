import { Router, type IRouter } from "express";
import healthRouter from "./health";
import executeRouter from "./execute";
import snippetsRouter from "./snippets";
import aiRouter from "./ai";
import autorunRouter from "./autorun";
import deepseekRouter from "./deepseek";
import geminiRouter from "./gemini";
import neuralEventsRouter from "./neural-events";
import messagesRouter from "./messages";
import diagnosticsRouter from "./diagnostics";
import cortexRouter from "./cortex";
import openAiRouter from "./openai";
import coherenceSimulationRouter from "./coherence-simulation";
import agentsSimulationRouter from "./agents-simulation";
import tradingStatusRouter from "./trading-status";
import { disableTelemetryCache } from "./telemetry-cache";
import workspaceRouter from "./workspace";

const router: IRouter = Router();

router.use([
  "/coherence-simulation", "/diagnostics", "/cortex/context",
  "/deepseek/chat", "/chat", "/openai/chat",
], disableTelemetryCache);

router.use(healthRouter);
router.use(workspaceRouter);
router.use(executeRouter);
router.use(snippetsRouter);
router.use(aiRouter);
router.use(deepseekRouter);
router.use(geminiRouter);
router.use(neuralEventsRouter);
router.use(messagesRouter);
router.use(diagnosticsRouter);
router.use(cortexRouter);
router.use(openAiRouter);
router.use(coherenceSimulationRouter);
router.use(agentsSimulationRouter);
router.use(tradingStatusRouter);
router.use(autorunRouter);

export default router;
